﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-Ha5otv5ZY7I9FvdrWBtR2ti6O49MX7GoTDnrzH0mtyU=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-YLGeXaapI0\/5IgZopewRJcFXomhRMlYYjugPLSyNjTY=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-+Q44zfEaCMmXduni5Td+IgCbk8sSUQwES2nWs+KKQz0=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-oUpLdS+SoLJFwf4bzA3iKD7TCm66oLkTpAQlVJ2s1wc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-s\/Is6Ey6jfNAEfXUIOyHrXXX+RcA8hzchYnuOIWUMl4=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-9wdNXQFE78LCNHo+Hq2eXMTx+YBf2gjsufVTJc8dAV0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-17dfgcEZWWwzdYO2F54AOXq\/irq+JA5KVCRdeFXVn0w=",
      "url": "dev-tools.png"
    },
    {
      "hash": "sha256-qU+KhVPK6oQw3UyjzAHU4xjRmCj3TLZUU\/+39dni9E0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-xD6jUSTcBgOuPVSNB\/ZFWKiUxCAOv+\/\/IGgQcCTCNFU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-x4BERyB5o3RU0aTD72ISKK1h2OgW2l8a4MkOB3\/pBTE=",
      "url": "installation.png"
    },
    {
      "hash": "sha256-S19W0Y8kxBU+cA31Bq3Lesnw3oDXKW4CIg9YiXOGsWQ=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-G2Gt\/NEghVOb03D3TQ6vquZsg+CQiQ\/oUFIZblldNJQ=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-pqULWa+N2teI5Hx1qo9PUuw+BZlrDKU55bdyRu39thU=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-vYWYo2GO4NXOhWlWi2u9bu5EkKBCPrsE8lVvnVCEu+M=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-Clpvfnon6MIuN4pdSssEsbuADpgUCn6T\/D57MOecUEY=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-jzHgXWAvWMkKIGFjZoT84tbe72E+H7CvTr\/Dryh4QPs=",
      "url": "_framework\/_bin\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-vX2A57GZDvMMuqbJjw3pGN9S6mC45jdeXtg1XFkSpbA=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-ZNjCIvlj9UbTZNvSF1roE4FMhBuIcK36O6HPpAj7zvI=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-gL0fJgVzIZjGTvFjrtV5kw+vOKl6HJUEfQKLujmcB7c=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-Do5EaIFub6MRfMhJ24rKVk+bs8nB0TBPn\/tgiG6T2r0=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-BdmWgLAH22j8aXXfYlKBe2vG5WN51DZzcKXQSKNadyA=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-JnCuMNcyL\/03iOvlPJPAwsktFyCsAe\/OgiGQlrl5WPI=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-COYRFh1Y65qO0Jo\/gDnGkuVVdBuCX+yeJ1SylplxlIw=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-hR0NlEq9lsRI2cbmREkEyfnPkDDAsalTuqSNvOeF8a0=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-OFdR9iqYfvmIfaASrazUXvtoJg7WOeuUMV+7Ctwsheg=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-3cbvJEo8k8VJVQwyEZWWQ6yGRFQW8\/219DaOnmsX3e4=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-zV\/OfJNfNsG404X30Pwkdymdh1KmZpTVEmG\/JNFVc\/k=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-DfohSvCqbcuggMczyM42E\/JlB906RTRKkZ2typstSBM=",
      "url": "_framework\/_bin\/mscorlib.dll"
    },
    {
      "hash": "sha256-\/cWXc8IRZW00j051xvNsv6uJpbva0xWLKlWhOuG+qEo=",
      "url": "_framework\/_bin\/PWA-SampleApp.dll"
    },
    {
      "hash": "sha256-LzNsEV6ZeGcCMEBVJDsTJ3fM1BmSJ\/enBejltNoXhuY=",
      "url": "_framework\/_bin\/System.Core.dll"
    },
    {
      "hash": "sha256-V03bluzilSTetDzxoflatb396ML8UhBa6FjPq0A5LDQ=",
      "url": "_framework\/_bin\/System.dll"
    },
    {
      "hash": "sha256-APvhQxgbe0N9owcokX1nJ4DdGZNsaZUExUdA1AuOPqg=",
      "url": "_framework\/_bin\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-SRQDLLJAy\/+GuEb4SOTeaFCy0LTaQohAOrQ2kJYOEcA=",
      "url": "_framework\/_bin\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-ofhlYaRlfrjYE67FH6MB2tTOP34jg75mPLyzuV7sRIk=",
      "url": "_framework\/_bin\/System.Net.Http.WebAssemblyHttpHandler.dll"
    },
    {
      "hash": "sha256-71Izs0jqQXYDlTUJJvwe41zdPBn36D9K6n1Vjww+TYw=",
      "url": "_framework\/_bin\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-s5YL+qu2Rno6v7sSahH2QAtppAYVTRLq4kS25LGW10s=",
      "url": "_framework\/_bin\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-\/2qpVXkcb7aUKj1CC4QymgixbVo+mqq0+rOCZg\/Kl80=",
      "url": "_framework\/_bin\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-rULU62wTEcFC1Fau\/V\/70lwB+gYE1\/+3opW+Yk2UNR8=",
      "url": "_framework\/_bin\/WebAssembly.Bindings.dll"
    },
    {
      "hash": "sha256-mPoqx7XczFHBWk3gRNn0hc9ekG1OvkKY4XiKRY5Mj5U=",
      "url": "_framework\/wasm\/dotnet.3.2.0.js"
    },
    {
      "hash": "sha256-3S0qzYaBEKOBXarzVLNzNAFXlwJr6nI3lFlYUpQTPH8=",
      "url": "_framework\/wasm\/dotnet.timezones.dat"
    },
    {
      "hash": "sha256-UC\/3Rm1NkdNdlIrzYARo+dO\/HDlS5mhPxo0IQv7kma8=",
      "url": "_framework\/wasm\/dotnet.wasm"
    },
    {
      "hash": "sha256-SPHS1EAPAcMFN4TEIUYl3FWtoCQTsNJch0XVGgok1eE=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-YO9k+b4uMK5xHPxV+fuRn3NAQSq+ebpxgPTFhRKhz+k=",
      "url": "_framework\/blazor.boot.json"
    }
  ],
  "version": "AG085ybN"
};
